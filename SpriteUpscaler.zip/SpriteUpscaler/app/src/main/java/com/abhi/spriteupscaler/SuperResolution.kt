package com.abhi.spriteupscaler

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.ceil
import kotlin.math.min

/**
 * On-device AI super-resolution using a bundled ESRGAN TFLite model
 * (assets/esrgan.tflite). The model is fixed at 128x128 -> 512x512
 * (4x scale factor), so arbitrary-sized sprite frames are padded,
 * split into 128x128 tiles, upscaled tile-by-tile, and stitched back
 * together. Alpha (transparency) is upscaled separately via bilinear
 * scaling since the model only handles RGB.
 */
class SuperResolution(context: Context) : AutoCloseable {

    companion object {
        const val TILE = 128
        const val SCALE = 4
    }

    private val interpreter: Interpreter

    init {
        val afd = context.assets.openFd("esrgan.tflite")
        val buffer: MappedByteBuffer = FileInputStream(afd.fileDescriptor).channel.map(
            FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength
        )
        interpreter = Interpreter(buffer)
    }

    /** Upscale a single frame 4x using the on-device AI model. */
    fun upscale(frame: Bitmap): Bitmap {
        val w = frame.width
        val h = frame.height
        if (w == 0 || h == 0) return frame

        val paddedW = ceil(w.toDouble() / TILE).toInt() * TILE
        val paddedH = ceil(h.toDouble() / TILE).toInt() * TILE

        val padded = padWithEdgeReplication(frame, paddedW, paddedH)

        val outCanvasBitmap = Bitmap.createBitmap(paddedW * SCALE, paddedH * SCALE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outCanvasBitmap)

        val tilesX = paddedW / TILE
        val tilesY = paddedH / TILE
        for (ty in 0 until tilesY) {
            for (tx in 0 until tilesX) {
                val tile = Bitmap.createBitmap(padded, tx * TILE, ty * TILE, TILE, TILE)
                val upscaledTile = runModel(tile)
                canvas.drawBitmap(upscaledTile, (tx * TILE * SCALE).toFloat(), (ty * TILE * SCALE).toFloat(), null)
            }
        }

        // Crop back to the exact 4x size of the original (unpadded) frame.
        val rgbResult = Bitmap.createBitmap(outCanvasBitmap, 0, 0, w * SCALE, h * SCALE)

        // Upscale alpha channel separately (bilinear) and merge it in.
        val alphaUpscaled = upscaleAlpha(frame, w * SCALE, h * SCALE)
        return mergeAlpha(rgbResult, alphaUpscaled)
    }

    private fun runModel(tile: Bitmap): Bitmap {
        val input = Array(1) { Array(TILE) { Array(TILE) { FloatArray(3) } } }
        val pixels = IntArray(TILE * TILE)
        tile.getPixels(pixels, 0, TILE, 0, 0, TILE, TILE)
        for (y in 0 until TILE) {
            for (x in 0 until TILE) {
                val p = pixels[y * TILE + x]
                input[0][y][x][0] = Color.red(p).toFloat()
                input[0][y][x][1] = Color.green(p).toFloat()
                input[0][y][x][2] = Color.blue(p).toFloat()
            }
        }

        val outSize = TILE * SCALE
        val output = Array(1) { Array(outSize) { Array(outSize) { FloatArray(3) } } }
        interpreter.run(input, output)

        val outBitmap = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888)
        val outPixels = IntArray(outSize * outSize)
        for (y in 0 until outSize) {
            for (x in 0 until outSize) {
                val r = clamp255(output[0][y][x][0])
                val g = clamp255(output[0][y][x][1])
                val b = clamp255(output[0][y][x][2])
                outPixels[y * outSize + x] = Color.rgb(r, g, b)
            }
        }
        outBitmap.setPixels(outPixels, 0, outSize, 0, 0, outSize, outSize)
        return outBitmap
    }

    private fun clamp255(v: Float): Int = min(255, maxOf(0, v.toInt()))

    private fun padWithEdgeReplication(src: Bitmap, targetW: Int, targetH: Int): Bitmap {
        if (src.width == targetW && src.height == targetH) return src
        val padded = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(padded)
        canvas.drawBitmap(src, 0f, 0f, null)

        val srcPixels = IntArray(src.width * src.height)
        src.getPixels(srcPixels, 0, src.width, 0, 0, src.width, src.height)

        // Extend right edge
        if (targetW > src.width) {
            val col = IntArray(src.height) { y -> srcPixels[y * src.width + (src.width - 1)] }
            for (x in src.width until targetW) {
                padded.setPixels(col, 0, 1, x, 0, 1, src.height)
            }
        }
        // Extend bottom edge (using padded's own current right-extended width)
        if (targetH > src.height) {
            val rowPixels = IntArray(targetW)
            padded.getPixels(rowPixels, 0, targetW, 0, src.height - 1, targetW, 1)
            for (y in src.height until targetH) {
                padded.setPixels(rowPixels, 0, targetW, 0, y, targetW, 1)
            }
        }
        return padded
    }

    private fun upscaleAlpha(src: Bitmap, targetW: Int, targetH: Int): Bitmap {
        return Bitmap.createScaledBitmap(src, targetW, targetH, true)
    }

    private fun mergeAlpha(rgb: Bitmap, alphaSource: Bitmap): Bitmap {
        val w = rgb.width
        val h = rgb.height
        val rgbPixels = IntArray(w * h)
        val alphaPixels = IntArray(w * h)
        rgb.getPixels(rgbPixels, 0, w, 0, 0, w, h)
        alphaSource.getPixels(alphaPixels, 0, w, 0, 0, w, h)

        val merged = IntArray(w * h)
        for (i in 0 until w * h) {
            val a = Color.alpha(alphaPixels[i])
            val r = Color.red(rgbPixels[i])
            val g = Color.green(rgbPixels[i])
            val b = Color.blue(rgbPixels[i])
            merged[i] = Color.argb(a, r, g, b)
        }
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(merged, 0, w, 0, 0, w, h)
        return result
    }

    override fun close() {
        interpreter.close()
    }
}

package com.abhi.spriteupscaler

import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream

/**
 * Kotlin port of the desktop Python splitter: slices a sprite sheet
 * bitmap into a rows x cols grid, with optional transparent-edge
 * trimming and auto-detection of the grid via blank separator scans.
 */
object SpriteSlicer {

    data class Grid(val rows: Int, val cols: Int)

    /** Detect grid by scanning for fully-transparent separator rows/cols. */
    fun autoDetectGrid(bitmap: Bitmap): Grid? {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        fun rowIsEmpty(y: Int): Boolean {
            val base = y * w
            for (x in 0 until w) {
                if (Color.alpha(pixels[base + x]) != 0) return false
            }
            return true
        }

        fun colIsEmpty(x: Int): Boolean {
            for (y in 0 until h) {
                if (Color.alpha(pixels[y * w + x]) != 0) return false
            }
            return true
        }

        fun countBands(isEmpty: (Int) -> Boolean, length: Int): Int {
            var bands = 0
            var prevEmpty = true
            for (i in 0 until length) {
                val empty = isEmpty(i)
                if (!empty && prevEmpty) bands++
                prevEmpty = empty
            }
            return bands
        }

        val rows = countBands(::rowIsEmpty, h)
        val cols = countBands(::colIsEmpty, w)
        return if (rows > 0 && cols > 0) Grid(rows, cols) else null
    }

    /** Trim fully-transparent edges off a single frame. */
    private fun trimTransparent(frame: Bitmap): Bitmap {
        val w = frame.width
        val h = frame.height
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)

        var left = w; var right = -1; var top = h; var bottom = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (Color.alpha(pixels[y * w + x]) != 0) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
            }
        }
        if (right < left || bottom < top) return frame // fully transparent, leave as-is
        return Bitmap.createBitmap(frame, left, top, right - left + 1, bottom - top + 1)
    }

    /**
     * Slice [sheet] into rows x cols frames, saving frame_001.png ...
     * into [outDir]. Returns the number of frames written.
     */
    fun slice(
        sheet: Bitmap,
        rows: Int,
        cols: Int,
        outDir: File,
        trim: Boolean,
        expectedCount: Int? = null
    ): Int {
        outDir.mkdirs()
        outDir.listFiles()?.forEach { it.delete() } // clear stale run

        val fw = sheet.width / cols
        val fh = sheet.height / rows
        var count = 0

        outer@ for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (expectedCount != null && count >= expectedCount) break@outer
                val left = c * fw
                val top = r * fh
                var frame = Bitmap.createBitmap(sheet, left, top, fw, fh)
                if (trim) frame = trimTransparent(frame)
                count++
                val file = File(outDir, "frame_%03d.png".format(count))
                FileOutputStream(file).use { out ->
                    frame.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
        }
        return count
    }
}

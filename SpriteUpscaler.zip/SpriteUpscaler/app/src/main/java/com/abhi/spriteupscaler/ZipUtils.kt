package com.abhi.spriteupscaler

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipUtils {
    /** Zips all files directly inside [sourceDir] into [zipFile]. */
    fun zipDirectory(sourceDir: File, zipFile: File) {
        if (zipFile.exists()) zipFile.delete()
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            sourceDir.listFiles()?.sortedBy { it.name }?.forEach { file ->
                if (file.isFile) {
                    zos.putNextEntry(ZipEntry(file.name))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
    }
}

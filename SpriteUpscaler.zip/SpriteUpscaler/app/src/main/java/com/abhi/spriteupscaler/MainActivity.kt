package com.abhi.spriteupscaler

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.abhi.spriteupscaler.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var sheetBitmap: Bitmap? = null
    private var sheetUri: Uri? = null

    private val framesDir by lazy { File(getExternalFilesDir(null), "SpriteUpscaler/frames") }
    private val upscaledDir by lazy { File(getExternalFilesDir(null), "SpriteUpscaler/upscaled") }
    private val zipFile by lazy { File(getExternalFilesDir(null), "SpriteUpscaler/sprites_upscaled.zip") }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadSheet(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPick.setOnClickListener { pickImage.launch("image/*") }
        binding.btnAutoDetect.setOnClickListener { autoDetect() }
        binding.btnSlice.setOnClickListener { doSlice() }
        binding.btnUpscale.setOnClickListener { doUpscale() }
        binding.btnShare.setOnClickListener { doShare() }
    }

    private fun loadSheet(uri: Uri) {
        sheetUri = uri
        contentResolver.openInputStream(uri)?.use { stream ->
            sheetBitmap = BitmapFactory.decodeStream(stream)
        }
        binding.imgPreview.setImageBitmap(sheetBitmap)
        status("Loaded sheet: ${sheetBitmap?.width}x${sheetBitmap?.height}px")
    }

    private fun autoDetect() {
        val bmp = sheetBitmap ?: run { status("Pick a sprite sheet first."); return }
        status("Auto-detecting grid…")
        lifecycleScope.launch {
            val grid = withContext(Dispatchers.Default) { SpriteSlicer.autoDetectGrid(bmp) }
            if (grid != null) {
                binding.editRows.setText(grid.rows.toString())
                binding.editCols.setText(grid.cols.toString())
                status("Auto-detected: ${grid.rows} rows x ${grid.cols} cols")
            } else {
                status("Couldn't auto-detect — enter rows/cols manually.")
            }
        }
    }

    private fun doSlice() {
        val bmp = sheetBitmap ?: run { status("Pick a sprite sheet first."); return }
        val rows = binding.editRows.text.toString().toIntOrNull()
        val cols = binding.editCols.text.toString().toIntOrNull()
        if (rows == null || cols == null || rows <= 0 || cols <= 0) {
            status("Enter valid rows and cols first.")
            return
        }
        val expected = binding.editExpectedCount.text.toString().toIntOrNull()
        val trim = binding.checkTrim.isChecked

        setBusy(true, "Slicing frames…")
        lifecycleScope.launch {
            val count = withContext(Dispatchers.Default) {
                SpriteSlicer.slice(bmp, rows, cols, framesDir, trim, expected)
            }
            setBusy(false, "Sliced $count frames -> ${framesDir.path}")
        }
    }

    private fun doUpscale() {
        val frames = framesDir.listFiles { f -> f.extension == "png" }?.sortedBy { it.name }
        if (frames.isNullOrEmpty()) {
            status("Slice frames first (step 1).")
            return
        }
        upscaledDir.mkdirs()
        upscaledDir.listFiles()?.forEach { it.delete() }

        setBusy(true, "Loading on-device AI model…")
        binding.progressBar.max = frames.size

        lifecycleScope.launch {
            withContext(Dispatchers.Default) {
                SuperResolution(this@MainActivity).use { sr ->
                    frames.forEachIndexed { index, file ->
                        val bmp = BitmapFactory.decodeFile(file.path)
                        val upscaled = sr.upscale(bmp)
                        val outFile = File(upscaledDir, file.name)
                        outFile.outputStream().use { out ->
                            upscaled.compress(Bitmap.CompressFormat.PNG, 100, out)
                        }
                        withContext(Dispatchers.Main) {
                            binding.progressBar.progress = index + 1
                            binding.txtStatus.text = "Upscaling ${index + 1}/${frames.size}…"
                        }
                    }
                }
            }
            setBusy(false, "Upscaled ${frames.size} frames -> ${upscaledDir.path}")
        }
    }

    private fun doShare() {
        val sourceDir = if (upscaledDir.listFiles()?.isNotEmpty() == true) upscaledDir else framesDir
        if (sourceDir.listFiles().isNullOrEmpty()) {
            status("Nothing to share yet — slice (and optionally upscale) first.")
            return
        }
        setBusy(true, "Zipping…")
        lifecycleScope.launch {
            withContext(Dispatchers.Default) { ZipUtils.zipDirectory(sourceDir, zipFile) }
            setBusy(false, "Zipped -> ${zipFile.path}")

            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", zipFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Save or send sprite ZIP"))
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        binding.progressBar.visibility = if (busy) android.view.View.VISIBLE else android.view.View.INVISIBLE
        if (!busy) binding.progressBar.progress = 0
        status(message)
        binding.btnPick.isEnabled = !busy
        binding.btnSlice.isEnabled = !busy
        binding.btnUpscale.isEnabled = !busy
        binding.btnShare.isEnabled = !busy
    }

    private fun status(msg: String) {
        binding.txtStatus.text = msg
    }
}

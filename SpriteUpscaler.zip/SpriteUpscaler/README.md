# Sprite Upscaler (Android)

Same pipeline as the desktop script — slice a sprite sheet into
numbered frames, then AI-upscale each one — but as a native Android
app you can build and run entirely from your phone, with no laptop
and no Android Studio needed.

- **Slice**: pick a sprite sheet from your gallery, enter rows x cols
  (or tap Auto-detect), optionally trim transparent edges — writes
  `frame_001.png` ... `frame_NNN.png`.
- **Upscale**: runs every frame through a bundled ESRGAN AI model
  **on-device** — fully offline, no internet, no server calls, no cost.
  4x scale factor.
- **Share**: zips the result and opens the Android share sheet, so you
  can send it to Drive, Telegram-to-self, WhatsApp, or wherever gets
  it back to your laptop later.

## Build it (from your phone, via GitHub Actions)

1. Create a new empty GitHub repo (via the GitHub mobile app or
   github.com in your browser).
2. Push this project to it. Easiest from a phone: open the **GitHub
   app → your repo → Add file → Upload files**, and upload this whole
   folder structure (or use `git` from Termux if you have it).
3. GitHub Actions kicks off automatically on push (workflow is at
   `.github/workflows/build-apk.yml`). It:
   - installs the Android SDK + JDK 17 on GitHub's cloud runner
   - downloads the free ESRGAN TFLite model and bundles it into the app
   - runs `gradle assembleDebug`
   - uploads the resulting `app-debug.apk` as a workflow artifact
4. In the repo's **Actions** tab, open the finished run, download the
   `sprite-upscaler-debug-apk` artifact (a zip containing the APK),
   and install it on your phone (you'll need to allow "install unknown
   apps" for your browser/files app once).

Build takes a few minutes. No local tooling required at any step.

## Notes on the AI model

The bundled model is the ESRGAN TFLite model from Google's official
TensorFlow Lite super-resolution example (Apache-licensed, free).
It's a general-purpose model (not specifically tuned for pixel art or
anime line art like waifu2x), so:

- Best results on hand-drawn / painted sprite art — matches what you
  said your sheets mostly are.
- For crisp pixel art, results may be softer than a dedicated
  pixel-art upscaler like waifu2x — the desktop script is still the
  better choice for that case once you're back on your laptop.
- Fixed 128x128 -> 512x512 tiling under the hood — frames of any size
  are padded, processed in tiles, and cropped back automatically, so
  you don't need to think about this.

## Notes on storage/permissions

Output is written to the app's own storage
(`Android/data/com.abhi.spriteupscaler/files/SpriteUpscaler/`), so the
app needs **no storage permissions at all**. Use the Share button to
get the ZIP out to wherever you actually need it.
